using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgenteControlador : MonoBehaviour
{
    public GameObject agentePrefab;
    public int agenteCount = 100;
    public Vector3 spawnArea = new Vector3(20, 0, 20);


    public ComputeShader agenteComputeShader; // O compute shader

    private ComputeBuffer positionBuffer;
    private ComputeBuffer velocityBuffer;

    private Vector3[] boidPositions;
    private Vector3[] boidVelocities;

    public Transform controlador; // Refer�ncia ao objeto controlador
    
    void Start()
    {
        boidPositions = new Vector3[agenteCount];
        boidVelocities = new Vector3[agenteCount];
        for (int i = 0; i < agenteCount; i++)
        {
            // Define uma posi��o aleat�ria dentro da �rea de spawn
            Vector3 position = new Vector3(
                Random.Range(-spawnArea.x / 2, spawnArea.x / 2),
                0,
                Random.Range(-spawnArea.z / 2, spawnArea.z / 2)
            );
            boidVelocities[i] = new Vector3(
            Random.Range(-1f, 1f),
            0,
            Random.Range(-1f, 1f)
            );

            // Instancia o boid
           GameObject boid =  Instantiate(agentePrefab, position, Quaternion.identity);
           boid.GetComponent<Agente>().controlador = controlador;

        }
        positionBuffer = new ComputeBuffer(agenteCount, sizeof(float) * 3);
        velocityBuffer = new ComputeBuffer(agenteCount, sizeof(float) * 3);

        positionBuffer.SetData(boidPositions);
        velocityBuffer.SetData(boidVelocities);
    }

    void Update()
    {
        // Define os par�metros do compute shader
        agenteComputeShader.SetFloat("neighborRadius", 1.5f);
        agenteComputeShader.SetFloat("separationWeight", 1.5f);
        agenteComputeShader.SetFloat("alignmentWeight", 1.0f);
        agenteComputeShader.SetFloat("cohesionWeight", 1.0f);
        agenteComputeShader.SetFloat("maxSpeed", 5.0f);
        agenteComputeShader.SetFloat("maxForce", 0.5f);

        // Passa os buffers de posi��o e velocidade
        agenteComputeShader.SetBuffer(0, "positions", positionBuffer);
        agenteComputeShader.SetBuffer(0, "velocities", velocityBuffer);
        agenteComputeShader.SetInt("boidCount", agenteCount); // Passe o n�mero de boids para o shader

        // Define o n�mero de grupos de threads para processar todos os boids
        int threadGroups = Mathf.CeilToInt((float)agenteCount / 256f);  // N�mero de grupos de threads necess�rios
        agenteComputeShader.Dispatch(0, threadGroups, 1, 1);  // Despacha os grupos de threads no eixo X

        // Recupera as posi��es e velocidades atualizadas da GPU
        positionBuffer.GetData(boidPositions);
        velocityBuffer.GetData(boidVelocities);

        // Atualiza a posi��o dos boids na cena
        for (int i = 0; i < agenteCount; i++)
        {
            // Atualize a posi��o dos boids na cena (usando os GameObjects associados)
            // Aqui voc� pode ajustar as posi��es de visualiza��o dos boids
        }
    }


}
